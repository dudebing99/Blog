# 查看KEY信息
> openssl rsa -noout -text -in myserver.key

# 查看CSR信息
> openssl req -noout -text -in myserver.csr

# 查看证书信息
> openssl x509 -noout -text -in ca.crt

# 验证证书（提示self signed）
> openssl verify selfsign.crt

# 通过根证书验证子证书的有效性
> openssl verify -CAfile ca.crt myserver.crt

# 去掉key的密码保护
> openssl rsa -in myserver.key -out server.key.insecure
