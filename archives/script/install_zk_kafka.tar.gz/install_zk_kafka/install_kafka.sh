#!/bin/sh

echo "download package"
curl -O ftp://192.168.2.2/pub/kafka_2.11-0.10.0.0.tar.gz

echo "install kafka"
tar -xzvf kafka_2.11-0.10.0.0.tar.gz
cd kafka_2.11-0.10.0.0

broker_id=$1
kafka=$2
zookeeper_connect=$3

echo "broker.id=$broker_id" >> config/server.properties
echo "listeners=PLAINTEXT://$kafka:9092" >> config/server.properties
echo "zookeeper.connect=$zookeeper_connect" >> config/server.properties

cd -
cp -rP kafka_2.11-0.10.0.0 /usr/local

cd -
rm -rf kafka_2.11-0.10.0.0/*

cd /usr/local/kafka_2.11-0.10.0.0/bin
nohup ./kafka-server-start.sh ../config/server.properties &

sleep 3
