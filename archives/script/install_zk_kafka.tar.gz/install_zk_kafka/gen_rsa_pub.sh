#!/bin/sh

if [ -e ~/.ssh/id_rsa.pub ]; then
    exit 0
fi

yum install expect -y

cat > gen_rsa_pub.exp << EOF
#!/usr/bin/expect -f

set timeout 30

spawn ssh-keygen -t rsa -P 'hello'
expect {
    "Enter file*" {
        send "\r";
        exp_continue
    }

    "Overwrite*" {
        send "n\r"
        exp_continue
    }

    "*#" {
        send "exit\r"
    }
}
EOF

chmod +x gen_rsa_pub.exp
./gen_rsa_pub.exp

rm -rf gen_rsa_pub.exp
