功能：
gen_rsa_pub.sh:         产生 rsa 公钥
install_zookeeper.sh：  安装 zookeeper
