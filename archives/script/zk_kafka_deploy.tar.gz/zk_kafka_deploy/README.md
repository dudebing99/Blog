功能：
部署 zookeeper/kafka 集群

说明：
1. 需要提前规划好 zookeeper/kafka 集群，并配置好 basic.info，详见 basic.info。
2. 可以支持 zookeeper/kafka 单机或集群部署
单机部署，配置信息参考 basic_example_standalone.info
集群部署，配置信息参考 basic_example_cluster.info
