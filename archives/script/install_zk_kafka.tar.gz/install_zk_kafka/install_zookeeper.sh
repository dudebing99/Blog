#!/bin/sh

echo "download package"
curl -O ftp://192.168.2.2/pub/zookeeper-3.4.6.tar.gz

echo "install zookeeper"
tar -xzvf zookeeper-3.4.6.tar.gz
cd zookeeper-3.4.6

zookeepers=$1
self_id=$2

echo $self_id > snapshot/myid

id=0
for zk in $zookeepers
do
    echo "server.$id=$zk:2888:3888" >> conf/zoo.cfg
    id=`expr $id + 1`
done

cd -
cp -rP zookeeper-3.4.6 /usr/local

echo "add env"
cat >> /etc/profile << EOF
export ZOOKEEPER_HOME=/usr/local/zookeeper-3.4.6
export PATH=\$PATH:\$ZOOKEEPER_HOME
EOF

echo "set env temporary"
export ZOOKEEPER_HOME=/usr/local/zookeeper-3.4.6
export PATH=$PATH:$ZOOKEEPER_HOME

cd -
rm -rf zookeeper-3.4.6/*

cd /usr/local/zookeeper-3.4.6/bin
./zkServer.sh start

echo "############################################"
echo "#                                          #"
echo "#  ATTENTION: RUN 'source /etc/profile'    #"
echo "#                                          #"
echo "############################################"
